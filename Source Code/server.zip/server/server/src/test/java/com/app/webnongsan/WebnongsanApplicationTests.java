package com.app.webnongsan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebnongsanApplicationTests {

	@Test
	void contextLoads() {
	}

}
