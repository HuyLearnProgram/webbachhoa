package com.app.webnongsan.util.exception;

public class StorageException extends Exception{
    public StorageException(String s) {
        super(s);
    }
}
