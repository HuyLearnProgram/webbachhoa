package com.app.webnongsan.util.exception;

public class ResourceInvalidException extends Exception{
    public ResourceInvalidException(String mess){
        super(mess);
    }
}
