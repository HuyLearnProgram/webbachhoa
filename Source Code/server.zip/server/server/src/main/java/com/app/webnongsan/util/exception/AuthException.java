package com.app.webnongsan.util.exception;

public class AuthException extends Exception{
   public AuthException(String s){
       super(s);
   }
}
