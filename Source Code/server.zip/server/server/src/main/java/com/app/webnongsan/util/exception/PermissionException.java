package com.app.webnongsan.util.exception;

public class PermissionException extends Exception{
    public PermissionException(String s){
        super(s);
    }
}